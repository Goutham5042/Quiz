package com.gkapps.getthrough;


import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;

public class HomeScreenActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        AsyncServiceCall asyncServiceCall=new AsyncServiceCall(HomeScreenActivity.this);
        asyncServiceCall.execute();

    }


   /* private class GetQuestions extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Toast.makeText(MainGameActivity.this,"Json Data is downloading",Toast.LENGTH_LONG).show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler(HomeScreenActivity.this);
            // Making a request to url and getting response
            String url = "http://licleader.com/fetchdata/categories.php";
            serviceRespInJSONString = sh.makeServiceCall(url);
            Log.d("Service response in JSON string : ",serviceRespInJSONString);
            parseJSONString(serviceRespInJSONString);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Intent intent = new Intent(HomeScreenActivity.this,CategoriesActivity.class);
            startActivity(intent);
            finish();
        }
    }*/




}
