package com.gkapps.getthrough;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.os.AsyncTask;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.Bundle;

import java.util.ArrayList;

public class AsyncServiceCall extends AsyncTask<Void, Void, Void> {

    Context asyncContext=null;
    String serviceRespInJSONString;
    public static ArrayList<String> categoriesList=new ArrayList<String>();


    public AsyncServiceCall(Context context)
    {
        asyncContext=context;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        //Toast.makeText(MainGameActivity.this,"Json Data is downloading",Toast.LENGTH_LONG).show();

    }

    @Override
    protected Void doInBackground(Void... arg0) {
        HttpHandler sh = new HttpHandler(asyncContext);
        // Making a request to url and getting response
        String url = "http://licleader.com/fetchdata/categories.php";
        serviceRespInJSONString = sh.makeServiceCall(url);
        Log.d("Service response in JSON string : ",serviceRespInJSONString);
        parseJSONString(serviceRespInJSONString);
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        super.onPostExecute(result);
        Intent intent = new Intent(asyncContext,CategoriesActivity.class);
        asyncContext.startActivity(intent);
        //asyncContext.finish();
    }

    public void parseJSONString(String jsonString)
    {
        try {
            JSONObject serviceRespInJSON = new JSONObject(jsonString);
            if (serviceRespInJSON != null) {
                JSONArray categories = serviceRespInJSON.getJSONArray("categories");

                for (int i = 0; i < categories.length(); i++) {
                    JSONObject currCategory = categories.getJSONObject(i);
                    String CategoryID =     currCategory.getString("CategoryID");
                    String CategoryDesc =     currCategory.getString("CategoryDesc");
                    categoriesList.add(CategoryDesc);

                }

            }

        }
        catch(JSONException e)
        {
            Log.d("ParsingError","Exception occured while parsing the service response");
        }
    }

}
