package com.gkapps.getthrough;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


public class CategoriesActivity extends AppCompatActivity {

    //ArrayList<String> categoriesList=new ArrayList<String>();
    //String categoriesArray[]={"GK","Maths","Computers"};

    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.categories);
         adapter = new ArrayAdapter<String>(this,
                R.layout.activity_listview, AsyncServiceCall.categoriesList);
        ListView listView = (ListView) findViewById(R.id.categories_list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected item text from ListView
                String selectedItem = (String) parent.getItemAtPosition(position);

                // Display the selected item text on TextView
                Log.d("Your favorite : " , selectedItem);
            }
        });


    }






}
