package sarveshchavan777.triviaquiz;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;


public class HomeScreen extends AppCompatActivity {
    ImageButton playGame,quit;
    TextView tQ;
    static public String serviceRespInJSONString;
    static public String selectedCategory;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_screen);
        //the below method will initialize views
        initViews();
        new GetQuestions().execute();
        //PlayGame button - it will take you to the MainGameActivity
        playGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*ImageButton ib = (ImageButton)view;
                selectedCategory=ib.getTex;
                */Intent intent = new Intent(HomeScreen.this,MainGameActivity.class);
                startActivity(intent);
                finish();
            }
        });

        //Quit button - This will quit the game
        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void initViews() {

        //initialize views here
        playGame =(ImageButton)findViewById(R.id.gk);
        quit = (ImageButton) findViewById(R.id.quit);
        tQ = (TextView)findViewById(R.id.appID);

        //Typeface - this is for fonts style
        Typeface typeface = Typeface.createFromAsset(getAssets(),"fonts/shablagooital.ttf");
        //playGame.setTypeface(typeface);
        //quit.setTypeface(typeface);
        tQ.setTypeface(typeface);
    }


    private class GetQuestions extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //Toast.makeText(MainGameActivity.this,"Json Data is downloading",Toast.LENGTH_LONG).show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler(HomeScreen.this);
            // Making a request to url and getting response
            String url = "http://licleader.com/fetchdata/fetchdetails.php";
            HomeScreen.serviceRespInJSONString = sh.makeServiceCall(url);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }
    }


}
