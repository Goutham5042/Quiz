package sarveshchavan777.triviaquiz;


public class JsontoJava {

    private Long ID;
    private String QUESTION;
    private String OPTION_1;
    private String OPTION_2;
    private String OPTION_3;
    private String OPTION_4;
    private String OPTION_5;
    private String ANSWER;
    private String CATEGORY;
    private String SUB_CATEGORY;

    public Long getID() {
        return ID;
    }

    public String getQUESTION() {
        return QUESTION;
    }

    public String getOPTION_1() {
        return OPTION_1;
    }

    public String getOPTION_2() {
        return OPTION_2;
    }

    public String getOPTION_3() {
        return OPTION_3;
    }

    public String getOPTION_4() {
        return OPTION_4;
    }

    public String getOPTION_5() {
        return OPTION_5;
    }

    public String getANSWER() {
        return ANSWER;
    }

    public String getCATEGORY() {
        return CATEGORY;
    }

    public String getSUB_CATEGORY() {
        return SUB_CATEGORY;
    }

    public JsontoJava(Long ID, String QUESTION, String OPTION_1, String OPTION_2, String OPTION_3, String OPTION_4, String OPTION_5, String ANSWER, String CATEGORY, String SUB_CATEGORY) {
        this.ID = ID;
        this.QUESTION = QUESTION;
        this.OPTION_1 = OPTION_1;
        this.OPTION_2 = OPTION_2;
        this.OPTION_3 = OPTION_3;
        this.OPTION_4 = OPTION_4;
        this.OPTION_5 = OPTION_5;
        this.ANSWER = ANSWER;
        this.CATEGORY = CATEGORY;
        this.SUB_CATEGORY = SUB_CATEGORY;
    }
}
